<html>
<head>
  <meta charset="UTF-8">
  <script language="javascript" type="text/javascript" src="p5.js"></script>
  <!-- uncomment lines below to include extra p5 libraries -->
	<script language="javascript" src="p5.dom.js"></script> <!--<script language="javascript" src="../addons/p5.sound.js"></script>-->
  <script language="javascript" type="text/javascript" src="string game zhenghui.js"></script>
  <!-- this line removes any default padding and style. you might only need one of these values set. -->
  <style> body {padding: 0; margin: 0;} </style>
</head>

<body>
</body>
</html>