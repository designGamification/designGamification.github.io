//Variables for the entire track start

var P1_x,P1_y,P2_x,P2_y,P3_x,P4_x,loop_x,bgcol,scalar;

var t,p,b,m,h,g,tab1,position,velocity,a_1,a_2,b_1, b_2,c_1,c_2,d_1,d_2,newpos_a,newpos_b,newpos_c,newpos_d;

var isOverP6, submit_button,next_try,next_period,thrill,fail_display,success_display,try_count;

var submission_count;
var initial_height,gforce;

var password_inp,password,password_submit;

var welcome;

var User_ID;

var R2;

var period;

var printSF;

var table, newRow;
var period1,period2,thrillarray,resultarray,multarray,periodarray;
var max_thrill_period_1,max_thrill_period_2;

var number_of_tries, number_of_periods;

var heightarray,dummy_thrill;

var sample_enjoyment

function setup() 
{
  createCanvas(windowWidth, windowHeight);
  P1_x=50;
  P1_y=floor(random(50,250)); 
  //P1_y=174;
  initial_height=650-P1_y;
  sample_enjoyment = 400*(initial_height- (500))*(500)/pow(600,2);
  P2_y=650;
  P2_x=300;
  P3_x=800;
  P4_x=1000;
  
  
  loop_x= (P2_x +P3_x )/2;
 
   //setup variables
  bgcol = 255;
  x_circle=[40000];
  y_circle=[40000];
  scalar =20;
  t=0;
  
  
  p=-1;

   b=0; //friction
   m=10; //mass
   h=0.001; //time increment
   g=9.8; //gravity

   multarray=[20];
   periodarray=[20];
   tab1= [4004];
   position=[40000];
   velocity=[40000];

   thrill=0;
   gforce=0;

  fail_display=0;
  printSF=0;
  success_display=0;
  
  try_count=0;
  submission_count=0;
  welcome=1;
  period=1;
  max_thrill_period_1=0;
  max_thrill_period_2=0;

  R2= 10 + pow(P3_x-loop_x,2)/160;
  number_of_tries=1;
  number_of_periods=3;

  for(var i=0;i<4005;i++)
  {
    tab1[i]=[];
  }

  intializearray();

  
  table = new p5.Table();
  table.addColumn('id');
  table.addColumn('period');
  table.addColumn('count');
  table.addColumn('thrill');
  table.addColumn('Intial Height');
  
  table.addColumn('Width of the dip');
  table.addColumn('Result');
  table.addColumn('Period1');
  table.addColumn('Period2');
  newRow = table.addRow();

  Id_submit=createButton('START \n GAME');
  Id_submit.size(80,40);
  Id_submit.position(windowWidth/2-40, windowHeight/2);
  Id_submit.mousePressed(writename);

  submit_button=createButton('Submit try');
  submit_button.size(80,20);
  submit_button.position(windowWidth-100, windowHeight-150);
  submit_button.mousePressed(showanim);

  password_inp=createInput();
  password_inp.position(windowWidth/2, windowHeight-100);

  password_submit=createButton('Submit');
  password_submit.size(80,20);
  password_submit.position(windowWidth/2, windowHeight-80);
  password_submit.mousePressed(getfile);

  next_try=createButton('Next try');
  next_try.size(80,40);
  next_try.position(windowWidth-100, windowHeight-50);
  next_try.mousePressed(nexttry);

  next_period=createButton('Next period');
  next_period.size(80,40);
  next_period.position(windowWidth-100, windowHeight-50);
  next_period.mousePressed(nextperiod);

  inp_P6=createInput();
  inp_P6.position(P4_x, 670);
  inp_P6.size(100,20);
  inp_P6.input(changeP6);
  
}

function draw() 
{
  if(welcome==1)
  {
    fill(0,0,0);
    noStroke();
    textSize(20);
    // textAlign(CENTER);
    text("Read the instructions before starting", windowWidth/2-100, windowHeight/2-100)
    Id_submit.show();
    submit_button.hide();
    password_inp.hide();
    password_submit.hide();
    next_try.hide();
    next_period.hide();
    
    inp_P6.hide();
  }
  else if(welcome==0)
  {
    if(period<number_of_periods+1)
    {
      Id_submit.hide();
      password_inp.hide();
      if(try_count==0 && period==1)
      {
        submit_button.show();
      }

      password_submit.hide();
      next_try.hide();
      next_period.hide();
      
      inp_P6.show();

      background(bgcol);
      fill(200, 200, 255);
      noStroke();
      rect(windowWidth-200, 0, 200, windowHeight);
      //rect(0, windowHeight - 150, windowWidth, 150);

      strokeWeight(4);
      stroke(0, 0, 0);
      for (var i = 0; i < 4005; i = i+1) 
      {
        point(tab1[i][0],tab1[i][1]);
      }

      

      fill(0,0,0);
      noStroke();
      textSize(20);
      textAlign(CENTER);
      text("Initial Height", 60, P1_y+100);
      text(initial_height,60, P1_y+120);
     
      text("Width of the dip", P3_x, 700);
      text(P3_x-loop_x,P3_x, 720);
      text("Radius of the dip", P3_x, 740);
      text(int(R2*100)/100,P3_x, 760);
      text("Vary Width", P3_x, 780);

      text("Period", windowWidth-150, 50);
      text(period,windowWidth-150, 70);
      text("Try",windowWidth-50, 50 );
      text(try_count,windowWidth-50, 70 );


      
      fill(0,0,0);
      noStroke();
      text("G force in the dip",  windowWidth-100, 200);
      text("Enjoyment", windowWidth-100, 280);
      fill(0,0,0);
      noStroke();
      text("Success or Failure",  windowWidth-100, 360);

      text("Given: At w = 500,\n the enjoyment value is",  windowWidth-300, 50);
      text(ceil(sample_enjoyment*1000)/1000, windowWidth-300, 100 )



          
          
      if(p>=0)
      {
        if(velocity[p]>=0 && x_circle[p]<=((P3_x+loop_x)/2)|| x_circle[p]>=((P3_x+loop_x)/2) && gforce<=4 || success_display==1)
        {
          fill(255, 0, 0);
          noStroke();
          ellipse(x_circle[p],y_circle[p], scalar, scalar);
        } else if( x_circle[p]>=((P3_x+loop_x)/2) && gforce>4 ||fail_display==1)
        {
          fill(0, 0, 255);
          noStroke();
          ellipse(x_circle[p],y_circle[p], scalar, scalar);
        }

        fill(255,0,0);
        textSize(20);
        

        if( x_circle[p]>=((P3_x+loop_x)/2) && gforce>4 ||fail_display==1)
        {
          if(printSF==0)
          {
            newRow.setNum('Result',0);
            newRow = table.addRow();
            printSF=1;
          }
          text("Unsuccessful attempt",  windowWidth-100, 400);
          if(gforce>4)
          {
            text(ceil(gforce*100)/100,  windowWidth-100, 240);
          }

          if(submission_count==0 && try_count<number_of_tries)
          {
             next_try.hide();

          } else if(submission_count==1 && try_count<number_of_tries){
            text("Click on next try",  windowWidth/2, windowHeight-50);
            next_try.show();
          } else if(submission_count==1 && try_count==number_of_tries )
          {
            text("Go to next period",  windowWidth/2, windowHeight-100);
            next_period.show();
          }else if(submission_count==0 && try_count==number_of_tries)
          {
            next_period.hide();
          }
          
          
          fail_display=1;
        }else if( x_circle[p]>=((P3_x+loop_x)/2) && gforce<=4 || success_display==1)
        {
          if(printSF==0)
          {
            newRow.setNum('Result',1);
            newRow = table.addRow();
            printSF=1;
          }
          success_display=1;
          text("Successful attempt",  windowWidth-100, 400);
          text(ceil(thrill*1000)/1000,  windowWidth-100, 320);
          text(ceil(gforce*100)/100,  windowWidth-100, 240);
          if(submission_count==0 && try_count<number_of_tries)
          {
             next_try.hide();

          } else if(submission_count==1 && try_count<number_of_tries){
            text("Click on next try",  windowWidth/2, windowHeight-50);
            next_try.show();
          } else if(submission_count==1 && try_count==number_of_tries)
          {
        
            text("Go to next period",  windowWidth/2, windowHeight-100);
            next_period.show();
          }else if(submission_count==0 && try_count==number_of_tries)
          {
            next_period.hide();
          }
        }
        

         p=p+200;
      }
      

      fill(242,10,234);
      noStroke();
      ellipse(P3_x,650,10,10);
      triangle(P3_x+5,650-10,P3_x+15,650,P3_x+5,650+10);
      triangle(P3_x-5,650-10,P3_x-15,650,P3_x-5,650+10);
     

      if(dist(P3_x,650,mouseX,mouseY)<=30)
      {
        isOverP6=true;
      }
      else
      {
        isOverP6=false;
      }
    }
  
    
        // draw stuff here
  } 
  if(period==number_of_periods+1)
    {
      background(bgcol);
      fill(0,0,0);
      noStroke();
      textSize(40);
      textAlign(CENTER);
      text("GAME OVER",windowWidth/2, windowHeight/2);
      submit_button.hide();
      next_try.hide();
      Id_submit.hide();
      next_try.hide();
      next_period.hide();
      
      inp_P6.hide();
      password_inp.show();
      password_submit.show(); 
      textSize(20);
      textAlign(CENTER);
      text("Your payment", windowWidth/2, windowHeight/2+100);
      text(floor(7 + (max_thrill_period_1+max_thrill_period_2)*3.5), windowWidth/2, windowHeight/2+120);
    }  //ellipse(mouseX, mouseY, 80, 80);
}

function mouseDragged()
{
  
 
  if (isOverP6 == true && p<0) {
    
    P3_x =mouseX;
    R2= 10 + pow(P3_x-loop_x,2)/160;
    P4_x=P3_x+200;
    inp_P6.position(P4_x,670);
    
    fail_display=0;
    success_display=0;
    printSF=0;
    
    
  
    gforce=0;
    for(var i=0; i<40000;i++)
    {
      position[i]=0;
      velocity[i]=0;
      x_circle[i]=0;
      y_circle[i]=0;
    }
    intializearray();
  }
 
}





function intializearray()
{
  
  t=0;
  tab1[0][0]=P1_x;
  tab1[0][1]=P1_y;
  tab1[0][2]=0;

  for (var i = 1; i <= 1000; i = i+1) 
  {
    t=t+0.001;
    tab1[i][0]=((pow((1-t),3))*P1_x + 3*pow((1-t),2)*t*200 + 3*pow((t),2)*(1-t)*100 + (pow(t,3))*P2_x);
    tab1[i][1]=((pow((1-t),3))*P1_y + 3*pow((1-t),2)*t*P1_y + 3*pow((t),2)*(1-t)*P2_y + (pow(t,3))*P2_y);
    tab1[i][2]=tab1[i-1][2]+dist(tab1[i-1][0],tab1[i-1][1],tab1[i][0],tab1[i][1]);
    tab1[i-1][3]=-((tab1[i][1]-tab1[i-1][1])/(tab1[i][0]-tab1[i-1][0]));
    if (i>2)
    {
      tab1[i-2][4]=(atan(tab1[i-1][3])-atan(tab1[i-3][3]))/(tab1[i-1][2]-tab1[i-3][2]);
      
    }
  }

  
  t=0;
  for (var i = 1001; i <= 2001; i = i+1) 
  {
    
    tab1[i][0]=P2_x + (loop_x-P2_x)*t;
    tab1[i][1]=650;
    tab1[i][2]=tab1[i-1][2]+dist(tab1[i-1][0],tab1[i-1][1],tab1[i][0],tab1[i][1]);
    tab1[i-1][3]=0;
    tab1[i-2][4]=0;
    t=t+0.001;
  }

  t=0;

  for (var i = 2002; i <= 3002; i = i+1) 
  {
    tab1[i][0]=loop_x + (P3_x - loop_x)*t;
    tab1[i][1]=650+20-R2 + sqrt(pow(R2,2)-pow((tab1[i][0]-(P3_x+loop_x)/2),2));
    tab1[i][2]=tab1[i-1][2]+dist(tab1[i-1][0],tab1[i-1][1],tab1[i][0],tab1[i][1]);
   tab1[i-1][3]=-((tab1[i][1]-tab1[i-1][1])/(tab1[i][0]-tab1[i-1][0]));
    
    tab1[i-2][4]=(atan(tab1[i-1][3])-atan(tab1[i-3][3]))/(tab1[i-1][2]-tab1[i-3][2]);
    //println(tab1[i-2][4]);
    
    t=t+0.001;
  }
  
  t=0;
  for (var i = 3003; i <= 4003; i = i+1) 
  {
    
    tab1[i][0]=P3_x + (P4_x-P3_x)*t;
    tab1[i][1]=650;
    tab1[i][2]=tab1[i-1][2]+dist(tab1[i-1][0],tab1[i-1][1],tab1[i][0],tab1[i][1]);
    tab1[i-1][3]=0;
    tab1[i-2][4]=0;
    t=t+0.001;
  }


}

function rungekutta()
{
  velocity[0]=1.5;
  
  position[0]=0;

  a_1=velocity[0];
   
   for(var j = 0; j < 4004; j = j+1) 
    {
     if((position[0]>=tab1[j][2])&&(position[0]<=tab1[j+1][2]))
       {
          x_circle[0]=tab1[j][0];
         
          y_circle[0]=tab1[j][1];
    
          a_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*velocity[0];
           break;
         
       }
    }
    
  b_1= velocity[0] + (h/2)*a_2;
   
  newpos_b=position[0]+(h/2)*a_1;
 
  for(var j = 0; j < 4004; j = j+1) 
    {
     if((newpos_b>=tab1[j][2])&&(newpos_b<=tab1[j+1][2]))
       {
         
           b_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*b_1;
           break;
         
       }
    }
    
    
  c_1=velocity[0] + (h/2)*b_2;
   
  newpos_c=position[0]+(h/2)*b_1;
  
  for(var j = 0; j < 4004; j = j+1) 
    {
     if((newpos_c>=tab1[j][2])&&(newpos_c<=tab1[j+1][2]))
       {
         
           c_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*c_1;
           break;
         
       }
    }
    
  d_1=velocity[0] + (h)*c_2;
   
  newpos_d=position[0]+(h)*c_1;

  for(var j = 0; j < 4004; j = j+1) 
    {
     if((newpos_d>=tab1[j][2])&&(newpos_d<=tab1[j+1][2]))
       {
         
           d_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*d_1;
           break;
         
       }
    }
  
  position[1]=position[0] + (h/6)*(a_1 + 2*b_1 + 2*c_1 + d_1);
  
  velocity[1]=velocity[0]+ (h/6)*(a_2 + 2*b_2 + 2*c_2 + d_2);

  for (var i = 0; i < 4004; i = i+1)
   {
     if((position[1]>=tab1[i][2])&&(position[1]<=tab1[i+1][2]))
       {
         x_circle[1]=tab1[i][0];
         
         y_circle[1]=tab1[i][1];
         
         break;
       }
   }

  for (var i = 2; i < 40000; i = i+1) 
  { 

    
    {
      a_1=velocity[i-1];
   
      for(var j = 0; j < 4004; j = j+1) 
      {
        if((position[i-1]>=tab1[j][2])&&(position[i-1]<=tab1[j+1][2]))
        {
         
         
           a_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*velocity[i-1];
           break;
         
         
        }
      }
    
      b_1= velocity[i-1] + (h/2)*a_2;
   
      newpos_b=position[i-1]+(h/2)*a_1;
 
      for(var j = 0; j < 4004; j = j+1) 
      {
       if((newpos_b>=tab1[j][2])&&(newpos_b<=tab1[j+1][2]))
        {
         
           b_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*b_1;
           break;
         
         
        }  
      }
    
    
      c_1=velocity[i-1] + (h/2)*b_2;
   
      newpos_c=position[i-1]+(h/2)*b_1;
  
      for(var j = 0; j < 4004; j = j+1) 
      {
        if((newpos_c>=tab1[j][2])&&(newpos_c<=tab1[j+1][2]))
        {
        
           c_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*c_1;
           break;
        }
      }
    
      d_1=velocity[i-1] + (h)*c_2;
   
      newpos_d=position[i-1]+(h)*c_1;

      for(var j = 0; j < 4004; j = j+1) 
      {
        if((newpos_d>=tab1[j][2])&&(newpos_d<=tab1[j+1][2]))
        {
         
           d_2=(-9.8*tab1[j][3]/sqrt(1+pow(tab1[j][3],2)))-(b/m)*d_1;
           break;
         
        }
      }
  
      position[i]=position[i-1] + (h/6)*(a_1 + 2*b_1 + 2*c_1 + d_1);
      velocity[i]=velocity[i-1]+ (h/6)*(a_2 + 2*b_2 + 2*c_2 + d_2);
      //println(velocity[i])

      for (var z = 0; z < 4004; z = z+1)
      {
      if((position[i]>=tab1[z][2])&&(position[i]<=tab1[z+1][2]))
        {
         x_circle[i]=tab1[z][0];
         
         y_circle[i]=tab1[z][1];

        if(z>=2010 && z<2508)
         {
          if(pow(velocity[i],2)*abs(tab1[z][4])/g>gforce) //  && tab1[z][4]!=-1/R || ((g*cos(atan(tab1[z][3])))<(pow(velocity[i],2)*abs(tab1[z][4])) && tab1[z][4]==-1/R 
            {
               gforce=pow(velocity[i],2)*abs(tab1[z][4])/g;
            }
            
         } 
          
         

        }
      }
    }
  
  }
}


function posparticle()
{
p=0;
}



function nexttry()
{
  if(submission_count==1)
  {
    p=-2;
    submit_button.show();
    submission_count=0;
    next_try.hide();
  }

}

function nextperiod()
{
  if(try_count==number_of_tries)
  {
    submit_button.show();
    next_period.hide();
    period+=1;
    if(period==number_of_periods+1)
    {
      period1=ceil(random(1,number_of_periods));
      println(period1);
      period2=ceil(random(1,number_of_periods));
      println(period2);
      if (period2==period1)
      {
        period2-=1;
      }
      newRow.setNum('Period1',period1);
      newRow.setNum('Period2',period2);
      periodarray=table.getColumn("period");
      thrillarray=table.getColumn("thrill");
      resultarray=table.getColumn("Result");
      heightarray=table.getColumn("Intial Height");
      for(var i=0; i<=table.getRowCount()-1;i++)
      {
        if(periodarray[i]==period1)
        {
          multarray[i]=thrillarray[i]*resultarray[i];
          dummy_thrill=100*(pow(heightarray[i],2)/pow(600,2));
          if(max_thrill_period_1<multarray[i])
         { 
            max_thrill_period_1=multarray[i]/dummy_thrill;
         }
        } else if(periodarray[i]==period2)
        {
          multarray[i]=thrillarray[i]*resultarray[i];
          dummy_thrill=100*( pow(heightarray[i],2)/pow(600,2));
          if(max_thrill_period_2<multarray[i])
         { 
            max_thrill_period_2=multarray[i]/dummy_thrill;
         }
        }
        else
        {
          multarray[i]=0;
        }
      }
      
    } 
    p=-2;
    submission_count=0;
    try_count=0;
    P1_y=floor(random(50,250));
    initial_height=650-P1_y;

    sample_enjoyment = 400*(initial_height- (500))*(500)/pow(600,2);
    
    fail_display=0;
    success_display=0;
    printSF=0;
    
  
    gforce=0;
      for(var i=0; i<40000;i++)
      {
        position[i]=0;
        velocity[i]=0;
        x_circle[i]=0;
        y_circle[i]=0;
      }
    intializearray();
  }
}
function showanim()
{
  if(submission_count==0)
  {
  try_count+=1;
  submission_count=1;
  for(var i=0; i<40000;i++)
      {
        position[i]=0;
        velocity[i]=0;
        x_circle[i]=0;
        y_circle[i]=0;
      }
  
  fail_display=0;
  success_display=0;
  printSF=0;
  
  gforce=0;
  rungekutta();
  posparticle();
  thrill= 400*(initial_height- (P3_x-loop_x))*(P3_x-loop_x)/pow(600,2);

  newRow.setNum('period',period);
  newRow.setNum('count',try_count);
  newRow.setNum('thrill',thrill);
  newRow.setNum('Intial Height',650-P1_y);
  newRow.setNum('Width of the dip',P3_x-loop_x);


  submit_button.hide();
}
  
}

function getfile()
{
  password=password_inp.value();
  if(int(password)==2015)
  {
    saveTable(table,'summary.csv');
  }
 
}

function writename()
{
  
  newRow.setNum('id', 23);
  welcome=0;
}




function changeP6()
{
  if(p<0)
  {
    P3_x =loop_x + float(inp_P6.value());
    R2= 10 + pow(P3_x-loop_x,2)/160;
    P4_x=P3_x+200;
    inp_P6.position(P4_x,670);
    fail_display=0;
    success_display=0;
    printSF=0;
  
    gforce=0;
    for(var i=0; i<40000;i++)
    {
      position[i]=0;
      velocity[i]=0;
      x_circle[i]=0;
      y_circle[i]=0;
    }
    intializearray();
  }


  
  if(inp_P6.value() == "terminate")
  {
    saveTable(table,'summary.csv');
  }

}



